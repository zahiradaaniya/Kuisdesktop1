
package formlampu.db;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import formlampu.model.Lampu;

public class DBHandler {
    public final Connection conn;

    public DBHandler(String driver) {
        this.conn = DBHelper.getConnection(driver);
    }
    public void addLampu(lampu lmp){
        String insertMhs = "INSERT INTO `mahasiswa`(`merk`, `harga`, `tgl_lahir`,`gender`,`prodi`)"
                + "VALUES (?,?,?,?,?)";
        try {
            PreparedStatement stmtInsert = conn.prepareStatement(insertMhs);
            stmtInsert.setString(1, lmp.getMerk());
            stmtInsert.setString(2, lmp.getHarga());
            stmtInsert.setString(3, lmp.getTanggalGaransi());
            stmtInsert.setString(4, lmp.getJenis());
            stmtInsert.setString(5, lmp.getQuantity());
            stmtInsert.execute();
        } catch (SQLException ex) {
            Logger.getLogger(DBHandler.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
}
