
package formlampu.model;

public class Lampu {
    private String merk;
    private String harga;
    private String tanggalgaransi;
    private String jenis;
    private String quantity;

    public Lampu(String merk, String harga, String tanggalgaransi, String jenis, String quantitty) {
        this.merk = merk;
        this.harga = harga;
        this.tanggalgaransi = tanggalgaransi;
        this.jenis = jenis;
        this.quantity = quantity;
    }

    public String getQuantity() {
        return quantity;
    }

    public void setQuantity(String quantity) {
        this.quantity = quantity;
    }

    public String getMerk() {
        return merk;
    }

    public void setMerk(String merk) {
        this.merk = merk;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getTanggalGaransi() {
        return tanggalgaransi;
    }

    public void setTanggalGaransi(String tanggalgaransi) {
        this.tanggalgaransi = tanggalgaransi;
    }

    public String getJenis() {
        return jenis;
    }

    public void setJenis(String jenis) {
        this.jenis = jenis;
    }
    
}
