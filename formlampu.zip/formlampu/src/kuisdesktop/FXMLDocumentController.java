package Kuisdesktop;

import java.net.URL;
import java.util.ArrayList;
import java.util.ResourceBundle;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Label;
import javafx.scene.control.Button;
import javafx.scene.control.ComboBox;
import javafx.scene.control.DatePicker;
import javafx.scene.control.Label;
import javafx.scene.control.RadioButton;
import javafx.scene.control.TextField;
import javafx.scene.control.ToggleGroup;
import formlampu.db.DBHandler;
import Formpengembalian.model.Lampu;


public class FXMLDocumentController implements Initializable {
    
     @FXML
    private Button btnSave;

    @FXML
    private ComboBox<?> cbQuantity;

    @FXML
    private DatePicker dpTanggalGaransi;

    @FXML
    private ToggleGroup jenis;

    @FXML
    private Label label;

    @FXML
    private RadioButton rdPijar;

    @FXML
    private RadioButton rdLED;

    @FXML
    private TextField tfMerk;

    @FXML
    private TextField tfHarga;

    
    @FXML
    private void handleButtonAction(ActionEvent event) {
        System.out.println("You clicked me!");
//        label.setText("Hello "+tfNama.getText());
        System.out.println(tfMerk.getText());
        System.out.println(tfMerk.getText());
        System.out.println(dpTanggalGaransi.getValue().toString());
        String jenis="";
        if (rdPijar.isSelected())
           jenis=rdPijar.getText();
        if (rdLED.isSelected())
           jenis=rdLED.getText();
        
        System.out.println(jenis);
        System.out.println(cbQuantity.getValue().toString());
//        Lampu(String merk, String harga, String tanggalGaransi, String jenis, String Quantity)
        Lampu lmp = new Lampu(tfMerk.getText(),tfHarga.getText(),dpTanggalGaransi.getValue().toString(),
            jenis,cbQuantity.getValue().toString());
        DBHandler dh = new DBHandler("MYSQL");
        dh.addLampu(lmp);
    }
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        // TODO
        ArrayList <String> list = new ArrayList<String>();
        list.add("<10");
        list.add(">50");
        ObservableList items = FXCollections.observableArrayList(list);
        cbProdi.setItems(items);
    }    
    
}
